// =====================================================
// controllers/auth.controller.js
// Signup, Login, Forgot Password, OTP
// FantasyNG Backend | ⚡ EXECUTED BY XCLUSIVE ⚡
// =====================================================

const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const User = require('../models/User');

// ── Generate JWT Token ────────────────────────────
const generateToken = (id) => {
  return jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || '30d',
  });
};

// ── @POST /api/auth/signup ─────────────────────────
// Register a new member
const signup = async (req, res) => {
  try {
    const { username, email, phone, password, gender, dateOfBirth } = req.body;

    // Basic validation
    if (!username || !email || !phone || !password || !gender || !dateOfBirth) {
      return res.status(400).json({ success: false, message: 'All fields are required.' });
    }

    // ── 18+ Age Check ──────────────────────────────
    const dob = new Date(dateOfBirth);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    const m = today.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < dob.getDate())) age--;

    if (age < 18) {
      return res.status(400).json({
        success: false,
        message: 'You must be 18 or older to join FantasyNG.',
      });
    }

    // Check if user already exists
    const existingUser = await User.findOne({
      $or: [{ email }, { phone }, { username }]
    });

    if (existingUser) {
      let field = existingUser.email === email ? 'Email' :
                  existingUser.phone === phone ? 'Phone number' : 'Username';
      return res.status(409).json({ success: false, message: `${field} already registered.` });
    }

    // Create user
    const user = await User.create({
      username,
      email,
      phone,
      passwordHash: password, // Will be hashed by pre-save hook
      gender,
      dateOfBirth: dob,
    });

    // Generate token
    const token = generateToken(user._id);

    res.status(201).json({
      success: true,
      message: 'Account created successfully! Welcome to FantasyNG.',
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        badge: user.badge,
        role: user.role,
        trustScore: user.trustScore,
      },
    });

  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).json({ success: false, message: 'Server error. Please try again.' });
  }
};

// ── @POST /api/auth/login ──────────────────────────
const login = async (req, res) => {
  try {
    const { emailOrPhone, password } = req.body;

    if (!emailOrPhone || !password) {
      return res.status(400).json({ success: false, message: 'Email/phone and password are required.' });
    }

    // Find user by email OR phone — include passwordHash
    const user = await User.findOne({
      $or: [{ email: emailOrPhone.toLowerCase() }, { phone: emailOrPhone }]
    }).select('+passwordHash');

    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    }

    // Check password
    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid credentials.' });
    }

    // Check account status
    if (user.status === 'banned') {
      return res.status(403).json({ success: false, message: 'Your account has been permanently banned.' });
    }

    // Update last seen and online status
    user.lastSeen = Date.now();
    user.isOnline = true;
    await user.save();

    const token = generateToken(user._id);

    res.json({
      success: true,
      message: 'Login successful.',
      token,
      user: {
        id: user._id,
        username: user.username,
        email: user.email,
        badge: user.badge,
        role: user.role,
        trustScore: user.trustScore,
        profilePhoto: user.profilePhoto,
      },
    });

  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ success: false, message: 'Server error. Please try again.' });
  }
};

// ── @POST /api/auth/logout ─────────────────────────
const logout = async (req, res) => {
  try {
    // Update online status
    await User.findByIdAndUpdate(req.user.id, {
      isOnline: false,
      lastSeen: Date.now(),
    });
    res.json({ success: true, message: 'Logged out successfully.' });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ── @POST /api/auth/forgot-password ───────────────
// Generate OTP and (in production) send via SMS or Email
const forgotPassword = async (req, res) => {
  try {
    const { emailOrPhone } = req.body;

    const user = await User.findOne({
      $or: [{ email: emailOrPhone }, { phone: emailOrPhone }]
    });

    if (!user) {
      // Send same response even if user not found (security best practice)
      return res.json({ success: true, message: 'If account exists, OTP has been sent.' });
    }

    // Generate 6-digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const otpHash = crypto.createHash('sha256').update(otp).digest('hex');

    user.resetPasswordOTP = otpHash;
    user.resetPasswordExpiry = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes
    await user.save();

    // TODO in production: Send OTP via SMS (Termii or Twilio) or email
    // For now, we log it — remove this in production!
    console.log(`[DEV ONLY] OTP for ${emailOrPhone}: ${otp}`);

    res.json({ success: true, message: 'OTP sent successfully. Valid for 10 minutes.' });

  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ── @POST /api/auth/reset-password ────────────────
const resetPassword = async (req, res) => {
  try {
    const { emailOrPhone, otp, newPassword } = req.body;

    const user = await User.findOne({
      $or: [{ email: emailOrPhone }, { phone: emailOrPhone }]
    });

    if (!user || !user.resetPasswordOTP || !user.resetPasswordExpiry) {
      return res.status(400).json({ success: false, message: 'Invalid or expired OTP.' });
    }

    // Check OTP expiry
    if (new Date() > user.resetPasswordExpiry) {
      return res.status(400).json({ success: false, message: 'OTP has expired. Please request a new one.' });
    }

    // Verify OTP
    const otpHash = crypto.createHash('sha256').update(otp).digest('hex');
    if (otpHash !== user.resetPasswordOTP) {
      return res.status(400).json({ success: false, message: 'Invalid OTP.' });
    }

    // Reset password
    user.passwordHash = newPassword; // Pre-save hook will hash it
    user.resetPasswordOTP = null;
    user.resetPasswordExpiry = null;
    await user.save();

    res.json({ success: true, message: 'Password reset successfully. Please log in.' });

  } catch (error) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
};

// ── @GET /api/auth/me ──────────────────────────────
const getMe = async (req, res) => {
  res.json({ success: true, user: req.user });
};

module.exports = { signup, login, logout, forgotPassword, resetPassword, getMe };
